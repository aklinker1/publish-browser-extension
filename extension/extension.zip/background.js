console.log('background script started');
